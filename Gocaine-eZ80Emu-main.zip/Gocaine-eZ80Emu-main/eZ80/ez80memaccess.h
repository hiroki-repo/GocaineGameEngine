//#pragma once
#ifndef EZ80MEMACC_H
#define EZ80MEMACC_H
#ifdef __cplusplus
extern "C" {
#endif
	int ez80memaccess(int prm_0, int prm_1, int prm_2);
#ifdef __cplusplus
}
#endif
#endif